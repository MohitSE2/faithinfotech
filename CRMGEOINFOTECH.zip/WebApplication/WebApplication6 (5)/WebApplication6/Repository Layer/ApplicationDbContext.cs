﻿using Domain_Layer.EntityMaper;
using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository_Layer
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {
        }

        public virtual DbSet<Batch> Batches { get; set; }
        public virtual DbSet<Course> Courses { get; set; }
        public virtual DbSet<CourseEnquiry> CourseEnquiries { get; set; }
        public virtual DbSet<RefreshToken> RefreshTokens { get; set; }
        public virtual DbSet<Resource> Resources { get; set; }
        public virtual DbSet<ResourceEnquiry> ResourceEnquiries { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<Trainee> Trainees { get; set; }
        public virtual DbSet<User> Users { get; set; }

        public virtual DbSet<Visit> Visits { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new CourseMap());
            modelBuilder.ApplyConfiguration(new ResourceMap());
            modelBuilder.ApplyConfiguration(new CourseEnquiryMap()); 
            modelBuilder.ApplyConfiguration(new ResourceEnquiryMap());
            modelBuilder.ApplyConfiguration(new TraineeMap());
            modelBuilder.ApplyConfiguration(new BatchMap());
            modelBuilder.ApplyConfiguration(new UserMap());
            modelBuilder.ApplyConfiguration(new RoleMap());
            modelBuilder.ApplyConfiguration(new RefreshTokenMap());
            modelBuilder.ApplyConfiguration(new VisitMap());

            base.OnModelCreating(modelBuilder);
        }
    }
}
