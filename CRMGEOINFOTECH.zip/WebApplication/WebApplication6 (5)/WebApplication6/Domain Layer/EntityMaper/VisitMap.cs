﻿using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Layer.EntityMaper
{
    public class VisitMap : IEntityTypeConfiguration<Visit>
    {
        public void Configure(EntityTypeBuilder<Visit> builder)
        {
            builder.HasKey(e => e.Id)
               .HasName("viewId");

            builder.Property(e => e.Day)
                .IsRequired()
                .HasColumnType("date")
                .HasColumnName("createdAt");

            builder.Property(e => e.Page)
                .IsRequired()
                .HasColumnType("varchar(20)")
                .HasColumnName("page");

            builder.Property(e => e.Views)
                .IsRequired()
                .HasColumnType("int")
                .HasColumnName("views");

        }
    }
}
