﻿using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Layer.EntityMaper
{
    public class CourseMap : IEntityTypeConfiguration<Course>
    {
        public void Configure(EntityTypeBuilder<Course> builder)
        {
            builder.HasKey(x => x.CourseId)
                .HasName("pk_courseId");
          

            builder.Property(x => x.CourseName)
                .HasColumnName("name")
                .HasColumnType("Varchar(100)")
                .IsRequired();
            builder.Property(x => x.CourseDesc)
               .HasColumnName("description")
               .HasColumnType("Varchar(500)")
               .IsRequired();
            
            builder.Property(x => x.CourseDuration)
                .HasColumnName("duration")
                .HasColumnType("varchar(10)")
                .IsRequired(); 
            builder.Property(x => x.CoursePrice)
                .HasColumnName("price")
                .HasColumnType("DECIMAL")
                .IsRequired();
            builder.Property(x => x.CourseAvailability)
              .HasColumnName("availability")
              .HasColumnType("bit")
              .IsRequired();
            builder.Property(x => x.Visibility)
              .HasColumnName("visibility")
              .HasColumnType("bit")
              .IsRequired();
        }
    }
}
