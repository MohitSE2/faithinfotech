﻿using Domain_Layer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service_Layer.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResourceEnquiryController : ControllerBase
    {
        private readonly ResourceEnquiryService _courseService;

        public ResourceEnquiryController(ResourceEnquiryService courseService)
        {
            _courseService = courseService;
        }

        [HttpGet]
        public IActionResult GetAllEnquiries()
        {
            var res = _courseService.GetAllResourcesEnquiry();
            if (res is not null)
            {
                return Ok(res);
            }
            return BadRequest("No Record Found");
        }

        [HttpGet("{id}")]
        public IActionResult GetEnquiry(int id)
        {
            var res = _courseService.GetResourceEnquiry(id);
            if (res is not null)
            {
                return Ok(res);
            }
            return BadRequest("No Record Found");
        }

        [HttpPost]
        public IActionResult InsertEnquiry(ResourceEnquiry course)
        {
            _courseService.InsertResourceEnquiry(course);
            return Ok("Data Saved SuccessFully");
        }


        [HttpPut]
        public IActionResult UpdateEnquiry(ResourceEnquiry course)
        {
            _courseService.UpdateResourceEnquiry(course);
            return Ok("Data Updated Successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEnquiry(int id)
        {
            _courseService.DeleteResourceEnquiry(id);
            return Ok("Data Deleted Successfully");
        }
        [HttpGet("status/{Status}")]
        public IEnumerable<ResourceEnquiry> GetStatusBasedEnquiries(String status)
        {
            return _courseService.getStatusBasedEnquiries(status);
        }

        [HttpPut("{id}/status/{status}")]
        public void updateEnquiryStatus(int id, String Status)
        {
            _courseService.updateEnquiryStatus(id, Status);
        }

        [HttpGet("insights")]
        public IActionResult getSummary()
        {
            return Ok(_courseService.ResourceEnquirySummary());
        }


    }
}

