﻿using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Repository_Layer;
using Repository_Layer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Service_Layer.Services
{
    public class ResourceEnquiryService : IResourceEnquiry
    {
        private IRepository<ResourceEnquiry> _repository;
        private readonly ApplicationDbContext context;
        public ResourceEnquiryService(IRepository<ResourceEnquiry> repository, ApplicationDbContext context)
        {
            _repository = repository;
            this.context = context;
        }
        public void DeleteResourceEnquiry(int Id)
        {
            ResourceEnquiry course = GetResourceEnquiry(Id);
            _repository.Remove(course);
            _repository.SaveChanges();
        }

        public IEnumerable<ResourceEnquiry> GetAllResourcesEnquiry()
        {
            return _repository.GetAll();
        }

        public ResourceEnquiry GetResourceEnquiry(int id)
        {
            return _repository.Get(id);
        }

        public void InsertResourceEnquiry(ResourceEnquiry resource)
        {
            _repository.Insert(resource);
        }
       
        public void UpdateResourceEnquiry(ResourceEnquiry resource)
        {
            _repository.Update(resource);
        }

        public IEnumerable<ResourceEnquiry> getStatusBasedEnquiries(String status) { 
        
            return context.ResourceEnquiries.Where(enquiry => enquiry.EnquiryStatus.CompareTo(status) == 0).AsEnumerable();
        }

        public void updateEnquiryStatus(int id, String status)
        {
            
            var enquiry = context.ResourceEnquiries.SingleOrDefault(x => x.ResourceEnqId==id);
            PropertyInfo propertyInfo = enquiry.GetType().GetProperty("EnquiryStatus");
            propertyInfo.SetValue(enquiry, status);
            context.Entry(enquiry).State = EntityState.Modified;
            context.SaveChanges();
        }

        public ResourceEnquirySummary ResourceEnquirySummary()
        {
            var c = 0;

            Dictionary<int, int> countMap = new Dictionary<int, int>();
            ResourceEnquirySummary summary = new ResourceEnquirySummary();
            summary.vacant = getStatusBasedEnquiries("Vacant").Count();
            summary.allocated = getStatusBasedEnquiries("Allocated").Count();
            summary.totalEnquiries = context.ResourceEnquiries.ToList().Count();

            var groupedList = context.ResourceEnquiries
                       .ToList();
            foreach (var enquiry in groupedList)
            {
                if (countMap.ContainsKey(enquiry.ResourceId))
                {
                    countMap[enquiry.ResourceId] += 1;
                }
                else
                {
                    countMap.Add(enquiry.ResourceId, 1);
                }
            }
            foreach (KeyValuePair<int, int> entry in countMap)
            {
                if (c < entry.Value)
                {
                    c = entry.Value;
                    summary.mostEnquiredCourse = context.Resources.SingleOrDefault(x => x.ResourceId == entry.Key).ResourceName;
                    summary.highestCourseEnquiries = c;
                }
            }
            return summary;
        }


    }

    public class ResourceEnquirySummary
    {
        public String mostEnquiredCourse { get; set; }
        public int highestCourseEnquiries { get; set; } = 0;
        public int vacant { get; set; } = 0;
        public int allocated { get; set; } = 0;
        public int totalEnquiries { get; set; } = 0;
    }
}
