﻿using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Repository_Layer;
using Repository_Layer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Service_Layer.Services
{
    public class CourseService : ICourseService
    {
        private IRepository<Course> _repository;
        private readonly ApplicationDbContext context;
        public CourseService(IRepository<Course> repository, ApplicationDbContext context)
        {
            _repository = repository;
            this.context = context;
        }
        public void DeleteCourse(int Id)
        {
            Course course = GetCourse(Id);
            _repository.Remove(course);
            _repository.SaveChanges();
        }

        public IEnumerable<Course> GetAllCourses()
        {
            return _repository.GetAll();
        }

        public Course GetCourse(int id)
        {
            return _repository.Get(id);
        }

        public void InsertCourse(Course course)
        {
            _repository.Insert(course);
        }

        public void UpdateCourse(Course course)
        {
            _repository.Update(course);
        }
        public void updateCourse(int id, String key, bool value)
        {
            var course = GetCourse(id);
            PropertyInfo propertyInfo = course.GetType().GetProperty(key);
            propertyInfo.SetValue(course, value);
            context.Entry(course).State = EntityState.Modified;
            context.SaveChanges();
        }

    }
}
