﻿using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Repository_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service_Layer.Services
{
    public class PageVisit
    {
        private readonly ApplicationDbContext context;
        private readonly DbSet<Visit> visits;
        public PageVisit(ApplicationDbContext context)
        {
            this.context = context;
            this.visits = context.Set<Visit>();
        }

        public void increaseViews(String Page)
        {
            var pageVisits = context.Visits.Where(v => v.Page.Equals(Page)).ToList();
            Visit page = null;
            foreach (Visit visit in pageVisits)
            {
                if (visit.Day.ToString("MM/dd/yyyy").Equals(DateTime.Now.ToString("MM/dd/yyyy")))
                {
                    page = visit;
                }
            }
            if (page == null)
            {
                var newVisit = new Visit();
                newVisit.Page = Page;
                visits.Add(newVisit);
            }
            else
            {
                page.Views += 1;
                visits.Update(page);
            }
            context.SaveChanges();

        }

        public bool VisitsExists(int id)
        {
            return context.Visits.Any(e => e.Id == id);
        }

    }
}
