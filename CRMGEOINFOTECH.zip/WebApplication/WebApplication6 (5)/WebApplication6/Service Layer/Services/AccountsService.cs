﻿
using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Repository_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Service_Layer.Services
{
    public class AccountsService
    {
        private ApplicationDbContext context;
        private DbSet<User> userEntity;
        public AccountsService(ApplicationDbContext context)
        {
            this.context = context;
            userEntity = context.Set<User>(); 
        }
        public void delAll()
        {
           /* foreach (User user in context.Users)
            {
                userEntity.Remove(user);
            }
            context.SaveChanges();*/
        }

        public void delEntity(int userId)
        {
            User user = getUser(userId);
            userEntity.Remove(user);
            context.SaveChanges();
        }

        public IEnumerable<User> getAllUsers()
        {
           return userEntity.AsEnumerable();
        }

        public User getUser(string userName, string password)
        {
            return userEntity.FirstOrDefault(user => user.UserName == userName && user.Password == password);    
        }

        public User getUser(int id)
        {
            return userEntity.SingleOrDefault(user => user.UserId == id);
        }

        public void insertEntity(User user)
        {
            context.Entry(user).State = EntityState.Added;
            context.SaveChanges();
        }

        public void updateUser( User user)
        {
            context.Entry(user).State = EntityState.Modified;
            context.SaveChanges();
        }

        public bool UserExists(int id)
        {
            if (getUser(id) != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
