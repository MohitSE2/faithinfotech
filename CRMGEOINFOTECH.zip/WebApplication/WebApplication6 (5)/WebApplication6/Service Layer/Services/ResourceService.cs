﻿using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Repository_Layer;
using Repository_Layer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Service_Layer.Services
{
    public class ResourceService : IResourceService
    {
        private IRepository<Resource> _repository;
        private readonly ApplicationDbContext context;
        public ResourceService(IRepository<Resource> repository, ApplicationDbContext context)
        {
            _repository = repository;
            this.context = context;
        }

        public void DeletetResource(int Id)
        {
            Resource resource = GetResource(Id);
            _repository.Remove(resource);
            _repository.SaveChanges();
        }

        public IEnumerable<Resource> GetAllResources()
        {
            return _repository.GetAll();
        }

        public Resource GetResource(int id)
        {
            return _repository.Get(id);
        }

       
        public void InsertResource(Resource resource)
        {
            _repository.Insert(resource);
        }

       

        public void UpdateResource(Resource resource)
        {
            _repository.Update(resource);
        }

        public void updateResource(int id, String key, bool value)
        {
            var course = GetResource(id);
            PropertyInfo propertyInfo = course.GetType().GetProperty(key);
            propertyInfo.SetValue(course, value);
            context.Entry(course).State = EntityState.Modified;
            context.SaveChanges();
        }
    }
}
