﻿using CRMSolution1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CRMsolution1.Repositories
{
    public class ResourceRepo
    {
        private readonly CRMDatabaseContext context;
        private readonly DbSet<Resource> resources;

        public ResourceRepo(CRMDatabaseContext context)
        {
            this.context = context;
            this.resources = context.Set<Resource>();
        }

        public void addResource(Resource resource)
        {
            resources.Add(resource);
            context.SaveChanges();
        }

        public List<Resource> getResources()
        {
            return resources.ToList();
        }

        public Resource getResource(int id)
        {
            return resources.SingleOrDefault(resource => resource.ResourceId == id);
        }

        public void updateResource(int id, String key, bool value)
        {
            var resource = getResource(id);
            PropertyInfo propertyInfo = resource.GetType().GetProperty(key);
            propertyInfo.SetValue(resource, value);
            context.Entry(resource).State = EntityState.Modified;
            context.SaveChanges();
        }

        public void updateResource(Resource resource)
        {
            context.Entry(resource).State = EntityState.Modified;
            context.SaveChanges();
        }
    }
}
