﻿using CRMSolution1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMsolution1.Repositories
{
    interface Repo<T> where T: BaseEntity
    {
        public void insertEntity(T entity);
        public void delEntity(T entity);
        public IEnumerable<T> getAll();
        public void delAll();
        public T getEntity(int id);
        public void updateEntity(T entity);
    }
}
