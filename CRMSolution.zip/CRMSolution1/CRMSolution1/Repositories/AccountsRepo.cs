﻿using CRMSolution1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMsolution1.Repositories
{
    interface AccountsRepo
    {
        public void saveUser(User user);
        public void delUser(int userId);
        public User getUser(String userName, String password);
        public List<User> getAllUsers();
        public void delAllusers();
    }
}
