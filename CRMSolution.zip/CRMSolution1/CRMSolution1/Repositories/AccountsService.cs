﻿using CRMSolution1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMsolution1.Repositories
{
    public class AccountsService
    {
        private CRMDatabaseContext context;
        private DbSet<User> userEntity;
        public AccountsService(CRMDatabaseContext context)
        {
            this.context = context;
            userEntity = context.Set<User>(); 
        }
        public void delAll()
        {
            foreach (User user in context.Users)
            {
                userEntity.Remove(user);
            }
            context.SaveChanges();
        }

        public void delEntity(int userId)
        {
            User user = getUser(userId);
            userEntity.Remove(user);
            context.SaveChanges();
        }

        public IEnumerable<User> getAllUsers()
        {
           return userEntity.AsEnumerable();
        }

        public User getUser(string userName, string password)
        {
            return userEntity.FirstOrDefault(user => user.UserName == userName && user.Password == password);    
        }

        public User getUser(int id)
        {
            return userEntity.SingleOrDefault(user => user.UserId == id);
        }

        public void insertEntity(User user)
        {
            context.Entry(user).State = EntityState.Added;
            context.SaveChanges();
        }

        public void updateUser( User user)
        {
            context.Entry(user).State = EntityState.Modified;
            context.SaveChanges();
        }
    }
}
