﻿using CRMSolution1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMsolution1.Repositories
{
    public class AccountsService : AccountsRepo
    {
        private CRMDatabaseContext context;
        private DbSet<User> userEntity;
        public AccountsService(CRMDatabaseContext context)
        {
            this.context = context;
            userEntity = context.Set<User>(); 
        }
        public void delAllusers()
        {
            foreach (User user in context.Users)
            {
                userEntity.Remove(user);
            }
            context.SaveChanges();
        }

        public void delUser(int userId)
        {
            User user = getUser(userId);
            userEntity.Remove(user);
        }

        public List<User> getAllUsers()
        {
           return userEntity.AsEnumerable().ToList();
        }

        public User getUser(string userName, string password)
        {
            return userEntity.FirstOrDefault(user => user.UserName == userName && user.Password == password);    
        }

        public User getUser(int id)
        {
            return userEntity.SingleOrDefault(user => user.UserId == id);
        }

        public void saveUser(User user)
        {
            context.Entry(user).State = EntityState.Added;
            context.SaveChanges();
        }

        public void updateUser(int id, User user)
        {
            context.Entry(user).State = EntityState.Modified;
            context.SaveChanges();
        }
    }
}
