﻿using CRMSolution1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CRMsolution1.Repositories
{
    public class ResourceEnquiryRepo
    {
        private readonly CRMDatabaseContext context;
        private readonly DbSet<ResourceEnquiry> enquiries;

        public void addEnquiry(ResourceEnquiry enquiry)
        {
            enquiries.Add(enquiry);
            context.SaveChanges();
        }

        public List<ResourceEnquiry> GetResourceEnquiries()
        {
            return enquiries.ToList();
        }

        public ResourceEnquiry GetResourceEnquir(int id)
        {
            return enquiries.SingleOrDefault(enquiry => enquiry.ResourceEnqId == id);
        }

        public void updateEnquiryStatus(int id, String status)
        {
            var enquiry = GetResourceEnquir(id);
            PropertyInfo propertyInfo = enquiry.GetType().GetProperty("EnquiryStatus");
            propertyInfo.SetValue(enquiry, status);
        }

        public void updateEnquiry(ResourceEnquiry enquiry)
        {
            context.Entry(enquiry).State = EntityState.Modified;
            context.SaveChanges();
        }

    }
}
