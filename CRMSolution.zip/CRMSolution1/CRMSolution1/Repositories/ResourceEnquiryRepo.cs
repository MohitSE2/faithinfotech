﻿using CRMSolution1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CRMsolution1.Repositories
{
    public class ResourceEnquiryRepo
    {
        private readonly CRMDatabaseContext context;
        private readonly DbSet<ResourceEnquiry> enquiries;

        public void addEnquiry(ResourceEnquiry enquiry)
        {
            enquiries.Add(enquiry);
            context.SaveChanges();
        }

        public IEnumerable<ResourceEnquiry> GetResourceEnquiries()
        {
            return enquiries.AsEnumerable();
        }

        public ResourceEnquiry GetResourceEnquir(int id)
        {
            return (ResourceEnquiry)enquiries.SingleOrDefault(enquiry => enquiry.ResourceEnqId == id);
        }

        public void updateEnquiryStatus(int id, String status)
        {
            
            var enquiry = GetResourceEnquir(id);
            PropertyInfo propertyInfo = enquiry.GetType().GetProperty("EnquiryStatus");
            propertyInfo.SetValue(enquiry, status);
            context.Entry(enquiry).State = EntityState.Modified;
            context.SaveChanges();
        }

        public void updateEnquiry(ResourceEnquiry enquiry)
        {
            context.Entry(enquiry).State = EntityState.Modified;
            context.SaveChanges();
        }

        public IEnumerable<ResourceEnquiry> getStatusBasedEnquiries(String status)
        {
            return enquiries.Where(enquiry => enquiry.EnquiryStatus.Equals(status));
        }

    }
}