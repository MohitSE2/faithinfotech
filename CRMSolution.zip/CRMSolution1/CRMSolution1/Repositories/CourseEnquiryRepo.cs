﻿using CRMSolution1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CRMsolution1.Repositories
{
    public class CourseEnquiryRepo
    {
        private readonly CRMDatabaseContext context;
        private readonly DbSet<CourseEnquiry> enquiries;

        public void addEnquiry(CourseEnquiry enquiry)
        {
            enquiries.Add(enquiry);
            context.SaveChanges();
        }

        public List<CourseEnquiry> GetCourseEnquiries()
        {
            return enquiries.ToList();
        }

        public CourseEnquiry GetCourseEnquiry(int id)
        {
            return enquiries.SingleOrDefault(enquiry => enquiry.CourseEnquiryId == id);
        }

        public void updateEnquiryStatus(int id, String status)
        {
            var enquiry = GetCourseEnquiry(id);
            PropertyInfo propertyInfo = enquiry.GetType().GetProperty("EnquiryStatus");
            propertyInfo.SetValue(enquiry, status);
        }

        public void updateEnquiry(CourseEnquiry enquiry)
        {
            context.Entry(enquiry).State = EntityState.Modified;
            context.SaveChanges();
        }




    }
}
