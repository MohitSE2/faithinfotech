﻿using CRMSolution1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CRMsolution1.Repositories
{
    public class CourseEnquiryRepo
    {
        private readonly CRMDatabaseContext context;
        private readonly DbSet<CourseEnquiry> enquiries;
        private readonly DbSet<Trainee> Trainee;


        public CourseEnquiryRepo(CRMDatabaseContext context)
        {
            this.context = context;
            enquiries = context.Set<CourseEnquiry>();
            Trainee = context.Set<Trainee>();
        }
        public void addEnquiry(CourseEnquiry enquiry)
        {
            enquiries.Add(enquiry);
            context.SaveChanges();
            
        }

        public IEnumerable<CourseEnquiry> GetCourseEnquiries()
        {
            return enquiries.AsEnumerable();
        }

        public CourseEnquiry GetCourseEnquiry(int id)
        {
            return enquiries.SingleOrDefault(enquiry => enquiry.CourseEnquiryId == id);
        }

        public void updateEnquiryStatus(int id, String status)
        {   if (status.Equals("Accepted"))
            {
                var trainee = new Trainee();
                trainee.CourseEnqId = id;
                Trainee.Add(trainee);
                
            }
            var enquiry = GetCourseEnquiry(id);
            PropertyInfo propertyInfo = enquiry.GetType().GetProperty("EnquiryStatus");
            propertyInfo.SetValue(enquiry, status); 
            context.Entry(enquiry).State = EntityState.Modified;
            context.SaveChanges();
        }

        public void updateEnquiry(CourseEnquiry enquiry)
        {
            context.Entry(enquiry).State = EntityState.Modified;
            context.SaveChanges();
        }

        public IEnumerable<CourseEnquiry> getStatusBasedEnquiries( String status)
        {
            var size = enquiries.ToList();
           return enquiries.Where(enquiry => enquiry.EnquiryStatus.CompareTo(status)==0);
        }



    }
}
