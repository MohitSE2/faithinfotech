﻿using CRMsolution1.Repositories;
using CRMSolution1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMSolution1.Repositories
{
    public class IRepository<T> : Repo<T> where T: BaseEntity     {
        private readonly CRMDatabaseContext context;
        private readonly DbSet<T> entities;

        public IRepository(CRMDatabaseContext context)
        {
            this.context = context;
            entities = context.Set<T>();
                
        }

        public void delAll()
        {
            foreach (T entity in entities)
            {
                entities.Remove(entity);
            }
            context.SaveChanges();
        }

        public void delEntity(T entity)
        {
            entities.Remove(entity);
            context.SaveChanges();
        }

        public IEnumerable<T> getAll()
        {
            return entities.AsEnumerable();
        }

        public T getEntity(int id)
        {
            return (T)entities.Where(entity => entity.Id == id);
        }

        public void insertEntity(T entity)
        {
            entities.Add(entity);
            context.SaveChanges();
        }

        public void updateEntity(T entity)
        {
            context.Entry(entity).State = EntityState.Modified;
            context.SaveChanges();
        }
    }
}
