﻿using CRMSolution1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CRMSolution1.Repositories
{
    public class CourseRepo
    {
        private readonly CRMDatabaseContext context;
        private readonly DbSet<Course> courses;

        public CourseRepo(CRMDatabaseContext context)
        {
            this.context = context;
            this.courses = context.Set<Course>();
        }

        public void addCourse(Course course) {
            courses.Add(course);
            context.SaveChanges();
        }

        public List<Course> getCourses()
        {
          return  courses.ToList();
        }

        public Course getCourse(int id)
        {
           return courses.SingleOrDefault(course => course.CourseId == id);
        }

        public void updateCourse(int id, String key,bool value)
        {
            var course = getCourse(id);
            PropertyInfo propertyInfo= course.GetType().GetProperty(key);
            propertyInfo.SetValue(course, value);
            context.Entry(course).State = EntityState.Modified;
            context.SaveChanges();
        }
    }
}
