﻿using CRMSolution1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMSolution1.Repositories
{
    public class VisitsRepo
    {
        private readonly CRMDatabaseContext context;
        private readonly DbSet<Visits> visits;
        public VisitsRepo(CRMDatabaseContext context)
        {
            this.context = context;
            this.visits= context.Set<Visits>();
        }

        public void increaseViews(String Page)
        {
            var pageVisits= visits.Where(visit => visit.Page.Equals(Page)).ToList();
            Visits page=null;
            foreach(Visits visit in pageVisits)
            {
                if (visit.Day.ToString("MM/dd/yyyy").Equals(DateTime.Now.ToString("MM/dd/yyyy"))){
                    page = visit;
                }
            }
           //var visit= pageVisits.SingleOrDefault(visit => visit.Day.ToString("MM/dd/yyyy").Equals(DateTime.Now.ToString("MM/dd/yyyy")));
            if (page == null)
            {
                var newVisit = new Visits();
                newVisit.Page = Page;
                visits.Add(newVisit);
            }
            else
            {
                page.Views += 1;
                visits.Update(page);
            }
            context.SaveChanges();

        }
    }
}
