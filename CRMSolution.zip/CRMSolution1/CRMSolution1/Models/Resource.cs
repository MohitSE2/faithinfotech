﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRMSolution1.Models
{
    public partial class Resource
    {
        public Resource()
        {
            ResourceEnquiries = new HashSet<ResourceEnquiry>();
        }

        public int ResourceId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        public int Price { get; set; }
        public bool Visibility { get; set; }
        public bool IsActive { get; set; }

        public virtual ICollection<ResourceEnquiry> ResourceEnquiries { get; set; }
    }
}
