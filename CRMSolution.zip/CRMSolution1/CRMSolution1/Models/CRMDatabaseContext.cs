﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using CRMSolution1.Models;

#nullable disable

namespace CRMSolution1.Models
{
    public partial class CRMDatabaseContext : DbContext
    {
        public CRMDatabaseContext()
        {
        }

        public CRMDatabaseContext(DbContextOptions<CRMDatabaseContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Batch> Batches { get; set; }
        public virtual DbSet<Course> Courses { get; set; }
        public virtual DbSet<CourseEnquiry> CourseEnquiries { get; set; }
        public virtual DbSet<RefreshToken> RefreshTokens { get; set; }
        public virtual DbSet<Resource> Resources { get; set; }
        public virtual DbSet<ResourceEnquiry> ResourceEnquiries { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<Trainee> Trainees { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=TOPXD1114P;Database= CRMDatabase;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Visits>(visit =>
            {
                visit.Property(v => v.Id).HasColumnType("int").HasColumnName("id");
                visit.Property(v => v.Day).HasColumnType("date").HasColumnName("day");
                visit.Property(v => v.Views).HasColumnType("int").HasColumnName("views");
                visit.Property(v => v.Page).IsRequired().HasColumnType("varchar(30)").HasColumnName("page");
            });

            modelBuilder.Entity<Batch>(entity =>
            {
                entity.Property(e => e.BatchId).HasColumnName("batchId");

                entity.Property(e => e.Capacity).HasColumnName("capacity");

                entity.Property(e => e.CourseId).HasColumnName("courseId");

                entity.Property(e => e.CreatedAt)
                    .HasColumnType("date")
                    .HasColumnName("createdAt");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("name");

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.Batches)
                    .HasForeignKey(d => d.CourseId)
                    .HasConstraintName("FK_Batches_Courses");
            });

            modelBuilder.Entity<Course>(entity =>
            {
                entity.Property(e => e.CourseId).HasColumnName("courseId");

                entity.Property(e => e.Description)
                    .HasColumnType("text")
                    .HasColumnName("description");

                entity.Property(e => e.Duration)
                    .HasMaxLength(10)
                    .HasColumnName("duration")
                    .IsFixedLength(true);

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("name");

                entity.Property(e => e.Price).HasColumnName("price");

                entity.Property(e => e.Visibility).HasColumnName("visibility");
            });

            modelBuilder.Entity<CourseEnquiry>(entity =>
            {
                entity.ToTable("CourseEnquiry");

                entity.Property(e => e.CourseEnquiryId).HasColumnName("courseEnquiryId");

                entity.Property(e => e.CourseId).HasColumnName("courseId");

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("DOB");

                entity.Property(e => e.Email)
                    .HasMaxLength(100)
                    .HasColumnName("email");

                entity.Property(e => e.EnquiryStatus)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("enquiryStatus");

                entity.Property(e => e.PhoneNo)
                    .HasMaxLength(10)
                    .HasColumnName("phoneNo")
                    .IsFixedLength(true);

                entity.Property(e => e.Qualification)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("qualification");

                entity.Property(e => e.TestScore).HasColumnName("testScore");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("userName");

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.CourseEnquiries)
                    .HasForeignKey(d => d.CourseId)
                    .HasConstraintName("FK_CourseEnquiry_Courses");
            });

            modelBuilder.Entity<RefreshToken>(entity =>
            {
                entity.HasKey(e => e.Token);

                entity.ToTable("RefreshToken");

                entity.Property(e => e.Token)
                    .HasMaxLength(300)
                    .HasColumnName("token");

                entity.Property(e => e.ExpiresAt).HasColumnType("datetime");

                entity.Property(e => e.IssuedAt)
                    .HasColumnType("datetime")
                    .HasColumnName("issuedAt");

                entity.Property(e => e.UserId).HasColumnName("userId");
            });

            modelBuilder.Entity<Resource>(entity =>
            {
                entity.Property(e => e.ResourceId).HasColumnName("resourceId");

                entity.Property(e => e.Description)
                    .HasColumnType("text")
                    .HasColumnName("description");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("name");

                entity.Property(e => e.Price).HasColumnName("price");

                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("type");

                entity.Property(e => e.Visibility).HasColumnName("visibility");
            });

            modelBuilder.Entity<ResourceEnquiry>(entity =>
            {
                entity.HasKey(e => e.ResourceEnqId);

                entity.ToTable("ResourceEnquiry");

                entity.Property(e => e.ResourceEnqId).HasColumnName("resourceEnqId");

                entity.Property(e => e.Email)
                    .HasMaxLength(100)
                    .HasColumnName("email");

                entity.Property(e => e.EnquiryStatus)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("enquiryStatus");

                entity.Property(e => e.PhoneNo)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("phoneNo");

                entity.Property(e => e.ResourceId).HasColumnName("resourceId");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("userName");

                entity.HasOne(d => d.Resource)
                    .WithMany(p => p.ResourceEnquiries)
                    .HasForeignKey(d => d.ResourceId)
                    .HasConstraintName("FK_ResourceEnquiry_Resources");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.RolesId);

                entity.Property(e => e.RolesId)
                    .HasMaxLength(20)
                    .HasColumnName("rolesId");

                entity.Property(e => e.RolesType)
                    .HasMaxLength(50)
                    .HasColumnName("rolesType");
            });

            modelBuilder.Entity<Trainee>(entity =>
            {
                entity.Property(e => e.TraineeId).HasColumnName("traineeId");

                entity.Property(e => e.BatchId).HasColumnName("batchId");

                entity.Property(e => e.CourseEnqId).HasColumnName("courseEnqId");

                entity.HasOne(d => d.CourseEnq)
                    .WithMany(p => p.Trainees)
                    .HasForeignKey(d => d.CourseEnqId)
                    .HasConstraintName("FK_Trainees_CourseEnquiry");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.UserId).HasColumnName("user_Id");

                entity.Property(e => e.Accepted).HasColumnName("accepted");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("email");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password");

                entity.Property(e => e.PhoneNo)
                    .HasMaxLength(10)
                    .HasColumnName("phoneNo")
                    .IsFixedLength(true);

                entity.Property(e => e.RolesId)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("rolesId");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("userName");

                entity.HasOne(d => d.Roles)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.RolesId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Users_Roles1");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

        public DbSet<CRMSolution1.Models.Visits> Visits { get; set; }
    }
}
