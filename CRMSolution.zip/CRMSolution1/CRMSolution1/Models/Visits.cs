﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMSolution1.Models
{
    public class Visits
    {
        public int Id { get; set; } = 0;
        public String Page { get; set; }
        public DateTime Day { get; set; } = DateTime.Now;
        public int Views { get; set; } = 1;
    }
}
