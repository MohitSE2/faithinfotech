﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRMSolution1.Models
{
    public partial class Course
    {
        public Course()
        {
            Batches = new HashSet<Batch>();
            CourseEnquiries = new HashSet<CourseEnquiry>();
        }

        public int CourseId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int Price { get; set; }
        public bool Visibility { get; set; }
        public bool IsActive { get; set; }
        public string Duration { get; set; }

        public virtual ICollection<Batch> Batches { get; set; }
        public virtual ICollection<CourseEnquiry> CourseEnquiries { get; set; }
    }
}
