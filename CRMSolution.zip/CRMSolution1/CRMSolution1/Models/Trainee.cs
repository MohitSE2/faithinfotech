﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRMSolution1.Models
{
    public partial class Trainee
    {
        public int TraineeId { get; set; } = 0;
        public int? BatchId { get; set; }
        public int? CourseEnqId { get; set; }
        /*public Trainee(int id,int? batchId, int? courseEnquiryId)
        {
            TraineeId = id;
            BatchId = batchId;
            CourseEnqId = courseEnquiryId;
        }*/
        public virtual CourseEnquiry CourseEnq { get; set; }
    }
}
