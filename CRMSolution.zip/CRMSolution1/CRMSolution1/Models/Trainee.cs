﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRMSolution1.Models
{
    public partial class Trainee
    {
        public int TraineeId { get; set; }
        public int? BatchId { get; set; }
        public int? CourseEnqId { get; set; }

        public virtual CourseEnquiry CourseEnq { get; set; }
    }
}
