﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CRMSolution1.Migrations
{
    public partial class CRM1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "page",
                table: "Visits",
                type: "varchar(30)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "page",
                table: "Visits");
        }
    }
}
