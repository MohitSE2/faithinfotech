﻿using CRMsolution1.Repositories;
using CRMSolution1.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMSolution1.Controllers
{
    [ApiController]
    [Route("api/courseEnquiry")]
    public class CourseEnquiryController : ControllerBase
    {
        private readonly CourseEnquiryRepo courseEnquiryRepo;

        public CourseEnquiryController(CourseEnquiryRepo courseEnquiryRepo)
        {
            this.courseEnquiryRepo = courseEnquiryRepo;
        }
        [HttpGet]
        public IEnumerable<CourseEnquiry> getCourseEnquiries()
        {
            return courseEnquiryRepo.GetCourseEnquiries();
        }

        [HttpGet("{id}")]
        public CourseEnquiry GetCourseEnquiry(int id)
        {
            return courseEnquiryRepo.GetCourseEnquiry(id);
        }

        [HttpPost]
        public void createEnquiry(CourseEnquiry courseEnquiry)
        {
            courseEnquiryRepo.addEnquiry(courseEnquiry);
        }

        [HttpPut("{id}/status/{Status}")]
        public void updateEnquiryStatus(int id, String Status)
        {
            courseEnquiryRepo.updateEnquiryStatus(id, Status);
        }

         [HttpPut("{id}")]
         public void updateEnquiry(int id, CourseEnquiry enquiry)
         {
             courseEnquiryRepo.updateEnquiry(enquiry);
         }

        [HttpGet("status/{Status}")]
        public IActionResult GetStatusBasedEnquiries( String status)
        {
            return Ok(courseEnquiryRepo.getStatusBasedEnquiries(status));
        }
    }

}
