﻿using CRMsolution1.Repositories;
using CRMSolution1.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMSolution1.Controllers
{
    [ApiController]
    [Route("api/resourceEnquiry")]
    public class ResourceEnquiryController : ControllerBase
    {
        private readonly ResourceEnquiryRepo resourceEnquiryRepo;

        public ResourceEnquiryController(ResourceEnquiryRepo resourceEnquiryRepo)
        {
            this.resourceEnquiryRepo = resourceEnquiryRepo;
        }
        [HttpGet]
        public List<ResourceEnquiry> getResourceEnquiries()
        {
            return resourceEnquiryRepo.GetResourceEnquiries();
        }

        [HttpGet("{id}")]
        public ResourceEnquiry GetResourceEnquiry(int id)
        {
            return resourceEnquiryRepo.GetResourceEnquir(id);
        }

        [HttpPost]
        public void createEnquiry(ResourceEnquiry enquiry)
        {
            resourceEnquiryRepo.addEnquiry(enquiry);
        }

        [HttpPut("{id}")]
        public void updateEnquiryStatus(int id, String Status)
        {
            resourceEnquiryRepo.updateEnquiryStatus(id, Status);
        }

        /*[HttpPut("{id}")]
        public void updateEnquiry(int id, ResourceEnquiry enquiry)
        {
            resourceEnquiryRepo.updateEnquiry(enquiry);
        }*/

    }
}
