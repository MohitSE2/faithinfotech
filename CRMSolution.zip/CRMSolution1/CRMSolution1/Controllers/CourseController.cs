﻿using CRMSolution1.Models;
using CRMSolution1.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMSolution1.Controllers
{
    [ApiController]
    [Route("api/courses")]
    public class CourseController : ControllerBase
    {
        private readonly CourseRepo courseRepo;
        public CourseController(CourseRepo courseRepo)
        {
            this.courseRepo = courseRepo;
        }
        [HttpPost]
        public void createCourse([FromBody] Course course)
        {
            courseRepo.addCourse(course);
        }

        [HttpGet]
        
        [Authorize(Roles =  "Manager")]
        public IEnumerable<Course> GetCourses()
        {
            return courseRepo.getCourses();
        }

        [HttpGet("{id}")]
        public Course GetCourse(int id)
        {
            return courseRepo.getCourse(id);
        }

        [HttpPut("{id}/isActive/{status}")]
        public void updateStatus(int id, int status)
        {
            courseRepo.updateCourse(id, "IsActive", Convert.ToBoolean(status));
        }

        [HttpPut("{id}/visibility/{status}")]
        public void updateVisibility(int id, int status)
        {
            courseRepo.updateCourse(id, "Visibility", Convert.ToBoolean(status));
        }
    }
}