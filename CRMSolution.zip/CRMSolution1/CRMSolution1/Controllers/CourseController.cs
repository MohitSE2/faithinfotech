﻿using CRMSolution1.Models;
using CRMSolution1.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMSolution1.Controllers
{
    [ApiController]
    [Route("api/courses")]
    public class CourseController : ControllerBase
    {
        private readonly CourseRepo courseRepo;
        public CourseController(CourseRepo courseRepo)
        {
            this.courseRepo = courseRepo;
        }
        [HttpPost]
        public void createCourse([FromBody] Course course)
        {
            courseRepo.addCourse(course);
        }

        [HttpGet]
        [Authorize]
        public List<Course> GetCourses()
        {
            return courseRepo.getCourses();
        }

        [HttpGet("{id}")]
        public Course GetCourse(int id)
        {
            return courseRepo.getCourse(id);
        }

        /*[HttpPost("{id}")]
        public void updateStatus(int id, bool visibility)
        {
            courseRepo.updateCourse(id, "visibility", visibility);
        }*/
        [HttpPost("{id}")]
        public void updateStatus( int id, Dictionary<String,Int32> dict)
        {
            if ( dict.GetValueOrDefault("IsActive")==1)
            {
                courseRepo.updateCourse(id, "IsActive", true);
            }
            else if (dict.GetValueOrDefault("IsActive") == 0)
            {
                courseRepo.updateCourse(id, "IsActive", false);
            }
            
        }
    }
}
