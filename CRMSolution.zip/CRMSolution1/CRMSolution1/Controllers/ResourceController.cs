﻿using CRMsolution1.Repositories;
using CRMSolution1.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRMSolution1.Controllers
{   [Route("api/resources")]
    [ApiController]
    public class ResourceController: ControllerBase
    {
        ResourceRepo resourceRepo;
        public ResourceController(ResourceRepo courseRepo)
        {
            this.resourceRepo = courseRepo;
        }
        [HttpPost]
        public void createResource(Resource resource)
        {
            resourceRepo.addResource(resource);
        }

        [HttpGet]
        public List<Resource> GetCourses()
        {
            return resourceRepo.getResources();
        }

        [HttpGet("{id}")]
        public Resource GetCourse(int id)
        {
            return resourceRepo.getResource(id);
        }

        [HttpPut("{id}")]
        public void updateStatus(Resource resource)
        {
            resourceRepo.updateResource(resource);
        }
        /*[HttpPut("{id}")]
        public void updateStatus(bool isActive, int id)
        {
            resourceRepo.updateResource(id, "isActive", isActive);

        }*/
    }
}
