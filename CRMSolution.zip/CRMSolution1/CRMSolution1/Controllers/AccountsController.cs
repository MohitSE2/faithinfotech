﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRMSolution1.Models;
using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;
using CRMsolution1.Repositories;
using System.Threading.Tasks;
using CRMSolution1.Repositories;
using Microsoft.AspNetCore.Authorization;

namespace CRMSolution1.Controllers
{
    [ApiController]
    [Route("api/accounts")]
    [AllowAnonymous]
    public class AccountsController : ControllerBase
    {
        private readonly AccountsService accountService;

        private readonly ILogger<AccountsController> logger;
        private readonly SignInManager signInManager;

        public AccountsController(ILogger<AccountsController> logger,
                                SignInManager signInManager,
                                JwtAuthService jwtAuthManager,
                                AccountsService accountService)
        {
            this.logger = logger;
            this.signInManager = signInManager;
            this.accountService = accountService;
        }


        
        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<ActionResult> Login([FromBody] LoginRequest request)
        {   

            if (!ModelState.IsValid) { return BadRequest(ModelState); }

            var result = await signInManager.SignIn(request.UserName, request.Password);

            if (!result.Success) return Unauthorized();

            logger.LogInformation($"User [{request.UserName}] logged in the system.");

            return Ok(new LoginResult
            {
                UserName = result.User.UserName,
                AccessToken = result.AccessToken,
                RefreshToken = result.RefreshToken
            });
        }


        [HttpPost("refreshtoken")]
        public async Task<ActionResult> RefreshToken([FromBody] RefreshTokenRequest request)
        {
            if (!ModelState.IsValid) { return BadRequest(ModelState); }

            var result = await signInManager.RefreshToken(request.AccessToken, request.RefreshToken);

            if (!result.Success) return Unauthorized();

            return Ok(new LoginResult
            {
                UserName = result.User.Email,
                AccessToken = result.AccessToken,
                RefreshToken = result.RefreshToken
            });
        }

        // GET: api/Accounts
        
        [HttpGet]
        [Authorize]
        public IEnumerable<User> GetUsers()
        {
            return accountService.getAllUsers();
        }

        // GET: api/Accounts/5
        [HttpGet("{id}")]
        public ActionResult<User> GetUser(int id)
        {
            var user = accountService.getUser(id);

            if (user == null)
            {
                return NotFound();
            }

            return user;
        }

        // PUT: api/Accounts/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public IActionResult PutUser(int id, User user)
        {
            if (id != user.UserId)
            {
                return BadRequest();
            }


            try
            {
                accountService.updateUser( user);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Accounts
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public void PostUser(User user)
        {
             accountService.insertEntity(user);
        }

        [HttpPut("{id}/register")]
        public void acceptUserRole(int id)
        {
           var user= accountService.getUser(id);
            user.Accepted = !user.Accepted;
            accountService.updateUser( user);

        }

        // DELETE: api/Accounts/5
        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            var user = accountService.getUser(id);
            if (user == null)
            {
                return NotFound();
            }

            accountService.delEntity(id);

            return NoContent();
        }

       public bool UserExists(int id)
        {
            if (accountService.getUser(id) != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }

    public class LoginRequest
    {
        [Required]
        public string UserName { get; set; }

        [Required]
        public string Password { get; set; }
    }

    public class LoginResult
    {
        public string UserName { get; set; }
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
    }

    public class RefreshTokenRequest
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
    }

        
    }

