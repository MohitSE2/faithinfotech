﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace AMS.Migrations
{
    public partial class AMS : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AssetType",
                columns: table => new
                {
                    at_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    at_name = table.Column<string>(type: "varchar(max)", unicode: false, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AssetType", x => x.at_id);
                });

            migrationBuilder.CreateTable(
                name: "Login",
                columns: table => new
                {
                    l_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    userName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    password = table.Column<string>(type: "varchar(300)", maxLength: 300, nullable: false),
                    userType = table.Column<string>(type: "varchar(30)", maxLength: 30, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Login", x => x.l_id);
                });

            migrationBuilder.CreateTable(
                name: "RefreshTokens",
                columns: table => new
                {
                    Token = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    userId = table.Column<int>(type: "int", nullable: true),
                    issuedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    password = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RefreshTokens", x => x.Token);
                });

            migrationBuilder.CreateTable(
                name: "AssetDefinition",
                columns: table => new
                {
                    ad_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ad_name = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    ad_type_id = table.Column<int>(type: "int", nullable: false),
                    ad_class = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AssetDefinition", x => x.ad_id);
                    table.ForeignKey(
                        name: "FK_AssetDefinition_AssetType",
                        column: x => x.ad_type_id,
                        principalTable: "AssetType",
                        principalColumn: "at_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Vendor",
                columns: table => new
                {
                    vd_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    vd_name = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    vd_type = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    vd_atype_id = table.Column<int>(type: "int", nullable: false),
                    vd_from = table.Column<DateTime>(type: "date", nullable: false),
                    vd_to = table.Column<DateTime>(type: "date", nullable: false),
                    vd_addr = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vendor", x => x.vd_id);
                    table.ForeignKey(
                        name: "FK_Vendor_AssetType",
                        column: x => x.vd_atype_id,
                        principalTable: "AssetType",
                        principalColumn: "at_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Registeration",
                columns: table => new
                {
                    u_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    firstName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    lastName = table.Column<byte[]>(type: "varbinary(50)", maxLength: 50, nullable: false),
                    age = table.Column<int>(type: "int", nullable: false),
                    gender = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    address = table.Column<byte[]>(type: "varbinary(300)", maxLength: 300, nullable: false),
                    phoneNo = table.Column<int>(type: "int", nullable: false),
                    l_Id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Registeration", x => x.u_Id);
                    table.ForeignKey(
                        name: "FK_Registeration_Login",
                        column: x => x.l_Id,
                        principalTable: "Login",
                        principalColumn: "l_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "AssetMaster",
                columns: table => new
                {
                    am_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    am_atype_id = table.Column<int>(type: "int", nullable: false),
                    am_make_id = table.Column<int>(type: "int", nullable: false),
                    am_ad_id = table.Column<int>(type: "int", nullable: false),
                    am_model = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    am_snumber = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    am_myear = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    am_pdate = table.Column<DateTime>(type: "date", nullable: false),
                    am_warranty = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false),
                    am_from = table.Column<DateTime>(type: "date", nullable: false),
                    am_to = table.Column<DateTime>(type: "date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AssetMaster", x => x.am_id);
                    table.ForeignKey(
                        name: "FK_AssetMaster_AssetDefinition",
                        column: x => x.am_ad_id,
                        principalTable: "AssetDefinition",
                        principalColumn: "ad_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_AssetMaster_AssetType",
                        column: x => x.am_atype_id,
                        principalTable: "AssetType",
                        principalColumn: "at_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_AssetMaster_Vendor",
                        column: x => x.am_make_id,
                        principalTable: "Vendor",
                        principalColumn: "vd_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PurchaseOrders",
                columns: table => new
                {
                    po_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    po_order_no = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    po_ad_id = table.Column<int>(type: "int", nullable: false),
                    po_type_id = table.Column<int>(type: "int", nullable: false),
                    po_qty = table.Column<int>(type: "int", nullable: false),
                    po_vendor_id = table.Column<int>(type: "int", nullable: false),
                    po_date = table.Column<DateTime>(type: "date", nullable: false),
                    po_ddate = table.Column<DateTime>(type: "date", nullable: false),
                    po_status = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PurchaseOrders", x => x.po_id);
                    table.ForeignKey(
                        name: "FK_PurchaseOrders_AssetDefinition",
                        column: x => x.po_ad_id,
                        principalTable: "AssetDefinition",
                        principalColumn: "ad_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrders_AssetType",
                        column: x => x.po_type_id,
                        principalTable: "AssetType",
                        principalColumn: "at_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrders_Vendor",
                        column: x => x.po_vendor_id,
                        principalTable: "Vendor",
                        principalColumn: "vd_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AssetDefinition_ad_type_id",
                table: "AssetDefinition",
                column: "ad_type_id");

            migrationBuilder.CreateIndex(
                name: "IX_AssetMaster_am_ad_id",
                table: "AssetMaster",
                column: "am_ad_id");

            migrationBuilder.CreateIndex(
                name: "IX_AssetMaster_am_atype_id",
                table: "AssetMaster",
                column: "am_atype_id");

            migrationBuilder.CreateIndex(
                name: "IX_AssetMaster_am_make_id",
                table: "AssetMaster",
                column: "am_make_id");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrders_po_ad_id",
                table: "PurchaseOrders",
                column: "po_ad_id");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrders_po_type_id",
                table: "PurchaseOrders",
                column: "po_type_id");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrders_po_vendor_id",
                table: "PurchaseOrders",
                column: "po_vendor_id");

            migrationBuilder.CreateIndex(
                name: "IX_Registeration_l_Id",
                table: "Registeration",
                column: "l_Id");

            migrationBuilder.CreateIndex(
                name: "IX_Vendor_vd_atype_id",
                table: "Vendor",
                column: "vd_atype_id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AssetMaster");

            migrationBuilder.DropTable(
                name: "PurchaseOrders");

            migrationBuilder.DropTable(
                name: "RefreshTokens");

            migrationBuilder.DropTable(
                name: "Registeration");

            migrationBuilder.DropTable(
                name: "AssetDefinition");

            migrationBuilder.DropTable(
                name: "Vendor");

            migrationBuilder.DropTable(
                name: "Login");

            migrationBuilder.DropTable(
                name: "AssetType");
        }
    }
}
