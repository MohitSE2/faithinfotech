﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AMS.Models;

namespace AMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssetDefinitionsController : ControllerBase
    {
        private readonly AMSContext _context;

        public AssetDefinitionsController(AMSContext context)
        {
            _context = context;
        }

        // GET: api/AssetDefinitions
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AssetDefinition>>> GetAssetDefinitions()
        {
            return await _context.AssetDefinitions.ToListAsync();
        }

        // GET: api/AssetDefinitions/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AssetDefinition>> GetAssetDefinition(int id)
        {
            var assetDefinition = await _context.AssetDefinitions.FindAsync(id);

            if (assetDefinition == null)
            {
                return NotFound();
            }

            return assetDefinition;
        }

        // PUT: api/AssetDefinitions/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAssetDefinition(int id, AssetDefinition assetDefinition)
        {
            if (id != assetDefinition.AdId)
            {
                return BadRequest();
            }

            _context.Entry(assetDefinition).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AssetDefinitionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AssetDefinitions
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<AssetDefinition>> PostAssetDefinition(AssetDefinition assetDefinition)
        {
            _context.AssetDefinitions.Add(assetDefinition);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAssetDefinition", new { id = assetDefinition.AdId }, assetDefinition);
        }

        // DELETE: api/AssetDefinitions/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAssetDefinition(int id)
        {
            var assetDefinition = await _context.AssetDefinitions.FindAsync(id);
            if (assetDefinition == null)
            {
                return NotFound();
            }

            _context.AssetDefinitions.Remove(assetDefinition);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AssetDefinitionExists(int id)
        {
            return _context.AssetDefinitions.Any(e => e.AdId == id);
        }
    }
}
