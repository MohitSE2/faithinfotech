﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AMS.Models;

namespace AMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssetMastersController : ControllerBase
    {
        private readonly AMSContext _context;

        public AssetMastersController(AMSContext context)
        {
            _context = context;
        }

        // GET: api/AssetMasters
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AssetMaster>>> GetAssetMasters()
        {
            return await _context.AssetMasters.ToListAsync();
        }

        // GET: api/AssetMasters/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AssetMaster>> GetAssetMaster(int id)
        {
            var assetMaster = await _context.AssetMasters.FindAsync(id);

            if (assetMaster == null)
            {
                return NotFound();
            }

            return assetMaster;
        }

        // PUT: api/AssetMasters/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAssetMaster(int id, AssetMaster assetMaster)
        {
            if (id != assetMaster.AmId)
            {
                return BadRequest();
            }

            _context.Entry(assetMaster).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AssetMasterExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AssetMasters
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<AssetMaster>> PostAssetMaster(AssetMaster assetMaster)
        {
            _context.AssetMasters.Add(assetMaster);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAssetMaster", new { id = assetMaster.AmId }, assetMaster);
        }

        // DELETE: api/AssetMasters/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAssetMaster(int id)
        {
            var assetMaster = await _context.AssetMasters.FindAsync(id);
            if (assetMaster == null)
            {
                return NotFound();
            }

            _context.AssetMasters.Remove(assetMaster);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AssetMasterExists(int id)
        {
            return _context.AssetMasters.Any(e => e.AmId == id);
        }
    }
}
