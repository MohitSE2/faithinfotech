﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AMS.Models;

namespace AMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegisterationsController : ControllerBase
    {
        private readonly AMSContext _context;

        public RegisterationsController(AMSContext context)
        {
            _context = context;
        }

        // GET: api/Registerations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Registeration>>> GetRegisterations()
        {
            return await _context.Registerations.ToListAsync();
        }

        // GET: api/Registerations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Registeration>> GetRegisteration(int id)
        {
            var registeration = await _context.Registerations.FindAsync(id);

            if (registeration == null)
            {
                return NotFound();
            }

            return registeration;
        }

        // PUT: api/Registerations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRegisteration(int id, Registeration registeration)
        {
            if (id != registeration.UId)
            {
                return BadRequest();
            }

            _context.Entry(registeration).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RegisterationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Registerations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("{type}")]
        public async Task<ActionResult<Registeration>> PostRegisteration(Registeration registeration, String type)
        {
            var login = _context.Logins.FirstOrDefault(x => x.UserName.Equals(registeration.FirstName));
            if (login == null)
            {
                var user = new Login();
                user.LId = 0;
                user.UserName = registeration.FirstName;
                user.UserType = type;
                user.Password = (registeration.FirstName + "123");
                _context.Logins.Add(user);
                await _context.SaveChangesAsync();
                registeration.LId = _context.Logins.FirstOrDefault(x => x.UserName.CompareTo(registeration.FirstName)==0).LId;
            }
            else
            {
                registeration.LId = login.LId;
            }
            _context.Registerations.Add(registeration);
            await _context.SaveChangesAsync();

            return Ok();
        }

        // DELETE: api/Registerations/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRegisteration(int id)
        {
            var registeration = await _context.Registerations.FindAsync(id);
            if (registeration == null)
            {
                return NotFound();
            }

            _context.Registerations.Remove(registeration);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool RegisterationExists(int id)
        {
            return _context.Registerations.Any(e => e.UId == id);
        }
    }
}
