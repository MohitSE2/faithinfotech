﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMS.Models
{
    public partial class AssetMaster
    {
        public int AmId { get; set; }
        public int AmAtypeId { get; set; }
        public int AmMakeId { get; set; }
        public int AmAdId { get; set; }
        public string AmModel { get; set; }
        public string AmSnumber { get; set; }
        public string AmMyear { get; set; }
        public DateTime AmPdate { get; set; }
        public string AmWarranty { get; set; }
        public DateTime AmFrom { get; set; }
        public DateTime AmTo { get; set; }

        public virtual AssetDefinition AmAd { get; set; }
        public virtual AssetType AmAtype { get; set; }
        public virtual Vendor AmMake { get; set; }
    }
}
