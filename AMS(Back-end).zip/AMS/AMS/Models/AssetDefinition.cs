﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMS.Models
{
    public partial class AssetDefinition
    {
        public AssetDefinition()
        {
            AssetMasters = new HashSet<AssetMaster>();
            PurchaseOrders = new HashSet<PurchaseOrder>();
        }

        public int AdId { get; set; }
        public string AdName { get; set; }
        public int AdTypeId { get; set; }
        public string AdClass { get; set; }

        public virtual AssetType AdType { get; set; }
        public virtual ICollection<AssetMaster> AssetMasters { get; set; }
        public virtual ICollection<PurchaseOrder> PurchaseOrders { get; set; }
    }
}
