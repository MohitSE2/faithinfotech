﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace AMS.Models
{
    public partial class AMSContext : DbContext
    {
        public AMSContext()
        {
        }

        public AMSContext(DbContextOptions<AMSContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AssetDefinition> AssetDefinitions { get; set; }
        public virtual DbSet<AssetMaster> AssetMasters { get; set; }
        public virtual DbSet<AssetType> AssetTypes { get; set; }
        public virtual DbSet<Login> Logins { get; set; }
        public virtual DbSet<PurchaseOrder> PurchaseOrders { get; set; }
        public virtual DbSet<Registeration> Registerations { get; set; }
        public virtual DbSet<Vendor> Vendors { get; set; }

        public virtual DbSet<RefreshToken> RefreshTokens { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=.;Database=AMS;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");

            modelBuilder.Entity<AssetDefinition>(entity =>
            {
                entity.HasKey(e => e.AdId);

                entity.ToTable("AssetDefinition");

                entity.Property(e => e.AdId).HasColumnName("ad_id");

                entity.Property(e => e.AdClass)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("ad_class");

                entity.Property(e => e.AdName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("ad_name");

                entity.Property(e => e.AdTypeId).HasColumnName("ad_type_id");

                entity.HasOne(d => d.AdType)
                    .WithMany(p => p.AssetDefinitions)
                    .HasForeignKey(d => d.AdTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AssetDefinition_AssetType");
            });

            modelBuilder.Entity<AssetMaster>(entity =>
            {
                entity.HasKey(e => e.AmId);

                entity.ToTable("AssetMaster");

                entity.Property(e => e.AmId).HasColumnName("am_id");

                entity.Property(e => e.AmAdId).HasColumnName("am_ad_id");

                entity.Property(e => e.AmAtypeId).HasColumnName("am_atype_id");

                entity.Property(e => e.AmFrom)
                    .HasColumnType("date")
                    .HasColumnName("am_from");

                entity.Property(e => e.AmMakeId).HasColumnName("am_make_id");

                entity.Property(e => e.AmModel)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("am_model");

                entity.Property(e => e.AmMyear)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("am_myear");

                entity.Property(e => e.AmPdate)
                    .HasColumnType("date")
                    .HasColumnName("am_pdate");

                entity.Property(e => e.AmSnumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("am_snumber");

                entity.Property(e => e.AmTo)
                    .HasColumnType("date")
                    .HasColumnName("am_to");

                entity.Property(e => e.AmWarranty)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("am_warranty");

                entity.HasOne(d => d.AmAd)
                    .WithMany(p => p.AssetMasters)
                    .HasForeignKey(d => d.AmAdId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AssetMaster_AssetDefinition");

                entity.HasOne(d => d.AmAtype)
                    .WithMany(p => p.AssetMasters)
                    .HasForeignKey(d => d.AmAtypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AssetMaster_AssetType");

                entity.HasOne(d => d.AmMake)
                    .WithMany(p => p.AssetMasters)
                    .HasForeignKey(d => d.AmMakeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AssetMaster_Vendor");
            });

            modelBuilder.Entity<AssetType>(entity =>
            {
                entity.HasKey(e => e.AtId);

                entity.ToTable("AssetType");

                entity.Property(e => e.AtId).HasColumnName("at_id");

                entity.Property(e => e.AtName)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("at_name");
            });

            modelBuilder.Entity<Login>(entity =>
            {
                entity.HasKey(e => e.LId);

                entity.ToTable("Login");

                entity.Property(e => e.LId).HasColumnName("l_id");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(300)
                    .HasColumnType("varchar")
                    .HasColumnName("password");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("userName");

                entity.Property(e => e.UserType)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnType("varchar")
                    .HasColumnName("userType");
            });

            modelBuilder.Entity<RefreshToken>(entity =>
            {
                entity.HasKey(e => e.Token);


                entity.Property(e => e.IssuedAt).HasColumnName("issuedAt").HasColumnType("datetime");

                entity.Property(e => e.ExpiresAt)
                    .HasColumnType("datetime")
                    .HasColumnName("password");

                entity.Property(e => e.UserId)
                .HasColumnName("userId").HasColumnType("int");
            });






            modelBuilder.Entity<PurchaseOrder>(entity =>
            {
                entity.HasKey(e => e.PoId);

                entity.Property(e => e.PoId).HasColumnName("po_id");

                entity.Property(e => e.PoAdId).HasColumnName("po_ad_id");

                entity.Property(e => e.PoDate)
                    .HasColumnType("date")
                    .HasColumnName("po_date");

                entity.Property(e => e.PoDdate)
                    .HasColumnType("date")
                    .HasColumnName("po_ddate");

                entity.Property(e => e.PoOrderNo)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("po_order_no");

                entity.Property(e => e.PoQty).HasColumnName("po_qty");

                entity.Property(e => e.PoStatus)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("po_status");

                entity.Property(e => e.PoTypeId).HasColumnName("po_type_id");

                entity.Property(e => e.PoVendorId).HasColumnName("po_vendor_id");

                entity.HasOne(d => d.PoAd)
                    .WithMany(p => p.PurchaseOrders)
                    .HasForeignKey(d => d.PoAdId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrders_AssetDefinition");

                entity.HasOne(d => d.PoType)
                    .WithMany(p => p.PurchaseOrders)
                    .HasForeignKey(d => d.PoTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrders_AssetType");

                entity.HasOne(d => d.PoVendor)
                    .WithMany(p => p.PurchaseOrders)
                    .HasForeignKey(d => d.PoVendorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrders_Vendor");
            });

            modelBuilder.Entity<Registeration>(entity =>
            {
                entity.HasKey(e => e.UId);

                entity.ToTable("Registeration");

                entity.Property(e => e.UId).HasColumnName("u_Id");

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(300)
                    .HasColumnType("varchar")
                    .HasColumnName("address");

                entity.Property(e => e.Age).HasColumnName("age");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("firstName");

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("gender");

                entity.Property(e => e.LId).HasColumnName("l_Id");

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnType("varchar")
                    .HasColumnName("lastName");

                entity.Property(e => e.PhoneNo).HasColumnName("phoneNo");

                entity.HasOne(d => d.LIdNavigation)
                    .WithMany(p => p.Registerations)
                    .HasForeignKey(d => d.LId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Registeration_Login");
            });

            modelBuilder.Entity<Vendor>(entity =>
            {
                entity.HasKey(e => e.VdId);

                entity.ToTable("Vendor");

                entity.Property(e => e.VdId).HasColumnName("vd_id");

                entity.Property(e => e.VdAddr)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("vd_addr");

                entity.Property(e => e.VdAtypeId).HasColumnName("vd_atype_id");

                entity.Property(e => e.VdFrom)
                    .HasColumnType("date")
                    .HasColumnName("vd_from");

                entity.Property(e => e.VdName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("vd_name");

                entity.Property(e => e.VdTo)
                    .HasColumnType("date")
                    .HasColumnName("vd_to");

                entity.Property(e => e.VdType)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("vd_type");

                entity.HasOne(d => d.VdAtype)
                    .WithMany(p => p.Vendors)
                    .HasForeignKey(d => d.VdAtypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Vendor_AssetType");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
