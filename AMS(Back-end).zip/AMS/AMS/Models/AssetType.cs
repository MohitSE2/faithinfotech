﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMS.Models
{
    public partial class AssetType
    {
        public AssetType()
        {
            AssetDefinitions = new HashSet<AssetDefinition>();
            AssetMasters = new HashSet<AssetMaster>();
            PurchaseOrders = new HashSet<PurchaseOrder>();
            Vendors = new HashSet<Vendor>();
        }

        public int AtId { get; set; }
        public string AtName { get; set; }

        public virtual ICollection<AssetDefinition> AssetDefinitions { get; set; }
        public virtual ICollection<AssetMaster> AssetMasters { get; set; }
        public virtual ICollection<PurchaseOrder> PurchaseOrders { get; set; }
        public virtual ICollection<Vendor> Vendors { get; set; }
    }
}
