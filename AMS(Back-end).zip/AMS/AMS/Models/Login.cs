﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMS.Models
{
    public partial class Login
    {
        public Login()
        {
            Registerations = new HashSet<Registeration>();
        }

        public int LId { get; set; }
        public string UserName { get; set; }
        public String Password { get; set; }
        public String UserType { get; set; }

        public virtual ICollection<Registeration> Registerations { get; set; }
    }
}
