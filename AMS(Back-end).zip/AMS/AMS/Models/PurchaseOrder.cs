﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMS.Models
{
    public partial class PurchaseOrder
    {
        public int PoId { get; set; }
        public string PoOrderNo { get; set; }
        public int PoAdId { get; set; }
        public int PoTypeId { get; set; }
        public int PoQty { get; set; }
        public int PoVendorId { get; set; }
        public DateTime PoDate { get; set; }
        public DateTime PoDdate { get; set; }
        public string PoStatus { get; set; }

        public virtual AssetDefinition PoAd { get; set; }
        public virtual AssetType PoType { get; set; }
        public virtual Vendor PoVendor { get; set; }
    }
}
