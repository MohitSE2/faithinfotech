﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AMS.Models
{
    public partial class Registeration
    {
        public int UId { get; set; }
        public string FirstName { get; set; }
        public String LastName { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public String Address { get; set; }
        public int PhoneNo { get; set; }
        public int LId { get; set; }

        public virtual Login LIdNavigation { get; set; }
    }
}
