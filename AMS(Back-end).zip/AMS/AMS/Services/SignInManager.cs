﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMS.Models;
using System.Security.Claims;


namespace AMS.Services
{
    public class SignInManager
    {
        private readonly ILogger<SignInManager> _logger;
        private readonly AMSContext _ctx;
        private readonly JwtAuthService _JwtAuthService;
        private readonly JwtTokenConfig _jwtTokenConfig;

        public SignInManager(ILogger<SignInManager> logger,
                             JwtAuthService jwtAuthService,
                             JwtTokenConfig jwtTokenConfig,
                             AMSContext ctx)
        {
            _logger = logger;
            _ctx = ctx;
            _JwtAuthService = jwtAuthService;
            _jwtTokenConfig = jwtTokenConfig;
        }

        public async System.Threading.Tasks.Task<SignInResult> SignIn(string userName, string password)
        {
            _logger.LogInformation($"Validating user [{userName}]", userName);

            SignInResult result = new SignInResult();

            if (string.IsNullOrWhiteSpace(userName)) return result;
            if (string.IsNullOrWhiteSpace(password)) return result;

            var user = await _ctx.Logins.Where(f => f.UserName == userName && f.Password == password).FirstOrDefaultAsync();
            if (user != null)
            {

                var claims = BuildClaims(user);
                result.User = user;
                result.AccessToken = _JwtAuthService.BuildToken(claims);
                result.RefreshToken = _JwtAuthService.BuildRefreshToken();

                _ctx.RefreshTokens.Add(new RefreshToken { UserId = user.LId, Token = result.RefreshToken, IssuedAt = DateTime.Now, ExpiresAt = DateTime.Now.AddMinutes(_jwtTokenConfig.RefreshTokenExpiration) });
                _ctx.SaveChanges();

                result.Success = true;
            };

            return result;
        }

        public async System.Threading.Tasks.Task<SignInResult> RefreshToken(string AccessToken, string RefreshToken)
        {

            ClaimsPrincipal claimsPrincipal = _JwtAuthService.GetPrincipalFromToken(AccessToken);
            SignInResult result = new SignInResult();

            if (claimsPrincipal == null) return result;

            string id = claimsPrincipal.Claims.First(c => c.Type == "id").Value;
            var user = await _ctx.Logins.FindAsync(Convert.ToInt32(id));

            if (user == null) return result;

            var token = await _ctx.RefreshTokens
                    .Where(f => f.UserId == user.LId
                            && f.Token == RefreshToken
                            && f.ExpiresAt >= DateTime.Now)
                    .FirstOrDefaultAsync();

            if (token == null) return result;

            var claims = BuildClaims(user);

            result.User = user;
            result.AccessToken = _JwtAuthService.BuildToken(claims);
            result.RefreshToken = _JwtAuthService.BuildRefreshToken();

            _ctx.RefreshTokens.Remove(token);
            _ctx.RefreshTokens.Add(new RefreshToken { UserId = user.LId, Token = result.RefreshToken, IssuedAt = DateTime.Now, ExpiresAt = DateTime.Now.AddMinutes(_jwtTokenConfig.RefreshTokenExpiration) });
            _ctx.SaveChanges();

            result.Success = true;

            return result;
        }

        private Claim[] BuildClaims(Login user)
        {
            //User is Valid
            
            var claims = new[]
            {
                new Claim("role",user.UserType),
                new Claim(ClaimTypes.Role, user.UserType),
                new Claim(ClaimTypes.Name,user.UserName)
 
                //Add Custom Claims here
            };

            return claims;
        }

}
    public class SignInResult
    {
        public bool Success { get; set; }
        public Login User { get; set; }
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }

        public SignInResult()
        {
            Success = false;
        }
    }
}
