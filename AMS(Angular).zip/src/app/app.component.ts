import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SecurityService } from './security/security.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private router: Router, public service: SecurityService){}
  ngOnInit(): void {
  }
  title = 'AMS-APP';
  public LogOut() {
    this.service.local="";
    this.router.navigateByUrl('');

  }
  
}
