import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";
import { analyzeAndValidateNgModules } from "@angular/compiler";

@Injectable({
  providedIn: "root",
})
export class AssetService {
  private apiUrl: string = environment.apiUrl;
  constructor(private httpClient: HttpClient) {}

  public GetPO(): Observable<any> {
    
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
    };
    return this.httpClient
      .post(
        `${this.apiUrl}PurchaseOrders`,
        httpOptions
      )
  }

  
  
     
 
}