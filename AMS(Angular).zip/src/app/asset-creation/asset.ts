export class Asset {
    AmId:number=0;
    AmAtypeId:number=0;
    AmMakeId:number=0;
    AmAdId:number=0;
    AmModel:number=0;
    AmSnumber:number=0;

  }