import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asset-creation',
  templateUrl: './asset-creation.component.html',
  styleUrls: ['./asset-creation.component.css']
})
export class AssetCreationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
