export class Register {
    UId: number = 0;
    FirstName!: string;
    LastName!: String;
    Age!: number;
    Gender!: String;
    Address!: String;
    PhoneNo!: string;
    RolesId!:String;
  }