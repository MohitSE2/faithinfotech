import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { SecurityService } from "src/app/security/security.service";
import { AccountService } from "../account.service";
import { Login } from "./login";
@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  constructor(
    private router: Router,
    private securityService: SecurityService,
    private activatedRoute: ActivatedRoute,
    private service: AccountService,
  ) {}

  loginViewModel!: Login;
  Login(): void {
    
    
      
    this.securityService.Login(this.loginViewModel).subscribe(
      (item) => {
        window.localStorage.setItem('token',item.accessToken);
        this.securityService.local= window.localStorage.getItem('token')?.split('.')[1];
        this.router.navigateByUrl('/Register');
        console.log(item);
        
        
      },
      (error) => {
        alert("invalid username or password");
        console.log(error);
      }
    );
    
  }
  ngOnInit(): void {
    this.loginViewModel = { UserName: "", Password: "" };
   
  }
}
