import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";
import { analyzeAndValidateNgModules } from "@angular/compiler";

@Injectable({
  providedIn: "root",
})
export class SecurityService {
  login:boolean=false;
  local!: any;
  private apiUrl: string = environment.apiUrl;
  constructor(private httpClient: HttpClient) {}

  public Login(userForm: any): Observable<any> {
    
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
    };
    return this.httpClient
      .post(
        `${this.apiUrl}accounts/login`,
        userForm,
        httpOptions
      )
  }

  
  roleMatch(allowedRoles: any[]): boolean {
    var isMatch = false;
    var payLoad = JSON.parse(window.atob(this.local));
    console.log(payLoad);
    var userRole = payLoad.role;
    allowedRoles.forEach(element => {
      if (userRole == element) {
        isMatch = true;
      }
    });
     
    return isMatch;
  } 
}