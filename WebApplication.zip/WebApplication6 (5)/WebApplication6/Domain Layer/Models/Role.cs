﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Domain_Layer.Models
{
    public partial class Role: BaseEntity
    {
        public Role()
        {
            Users = new HashSet<User>();
        }

        public string RolesId { get; set; }
        public string RolesType { get; set; }

        public virtual ICollection<User> Users { get; set; }
    }
}
