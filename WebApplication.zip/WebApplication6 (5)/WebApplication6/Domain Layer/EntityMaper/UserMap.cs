﻿using Domain_Layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Layer.EntityMaper
{
    public class UserMap : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> builder)
        {
            builder.HasKey(e => e.UserId)
               .HasName("userId");

            builder.Property(e => e.UserName)
                .IsRequired()
                .HasMaxLength(50)
                .HasColumnName("userName");

            builder.Property(e => e.Email)
                .IsRequired()
                .HasMaxLength(100)
                .HasColumnName("email");

            builder.Property(e => e.RolesId)
                .HasColumnName("rolesId");

            builder.Property(e => e.PhoneNo)
                .HasMaxLength(10)
                .HasColumnName("phoneNo");

            builder.Property(e => e.Password)
                .HasMaxLength(50)
                .HasColumnName("password");

            builder.Property(e => e.Accepted)
                .HasColumnType("bit")
                .IsRequired()
                .HasDefaultValue(false)
                .HasColumnName("accepted");

            builder.HasOne(d => d.Role)
                .WithMany(p => p.Users)
                .HasForeignKey(d => d.RolesId)
                .HasConstraintName("FK_Roles_Users");
        }
    }
}
