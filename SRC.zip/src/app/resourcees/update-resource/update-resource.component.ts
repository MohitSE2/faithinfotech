import { Component, OnInit } from '@angular/core';
import { UpdateServiceService } from 'src/app/shared/update-service.service';

@Component({
  selector: 'app-update-resource',
  templateUrl: './update-resource.component.html',
  styleUrls: ['./update-resource.component.css']
})
export class UpdateResourceComponent implements OnInit {

  constructor(public service: UpdateServiceService) { }

  ngOnInit(): void {
  }

  updateResource():void{
    this.service.update("Resource",this.service.Resource).subscribe((res) =>{
        alert(`Course Updated Successfully`);
      },
      (error) =>{
          alert(`Error occured while updating the course`);
        }
      
    );
  
   }

}
