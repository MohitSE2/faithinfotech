import { Component, OnInit } from '@angular/core';
import { InsightService } from '../manager/insights/insights.service';

@Component({
  selector: 'app-resourcees',
  templateUrl: './resourcees.component.html',
  styleUrls: ['./resourcees.component.css']
})
export class ResourceesComponent implements OnInit {

  constructor(private insight: InsightService) { }

  ngOnInit(): void {
    this.insight.Visited("Resources").subscribe(
      (item) => {
      },
      (error) => {
        alert("PageVisits Error occured");
      }
      );
  }

}
