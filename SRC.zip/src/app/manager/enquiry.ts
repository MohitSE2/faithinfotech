export class Enquiry {
    controller:string="";
    status:string="";
}