import { Component, OnInit } from '@angular/core';
import { ManagerService } from '../shared/manager.service';
import { NgForm } from '@angular/forms';
import { Enquiry } from './enquiry';
import { FormControl } from '@angular/forms';
import { ViewChild } from '@angular/core';


@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})

export class ManagerComponent implements OnInit {
  
  checkResponse:boolean=false;
  enquiries:any;
  registrationViewModel: Enquiry;
  courseEnquiry:any;

  @ViewChild("registrationForm")  form!: FormControl;

  constructor(private service:ManagerService) { 
    this.registrationViewModel = new Enquiry();
  }

  ngOnInit(): void {
  }

  submitRegistration():any{
    this.service.getStatusBasedEnquiry(this.registrationViewModel.controller,this.registrationViewModel.status).subscribe(res=>{
      this.checkResponse=true;
      this.enquiries=res;
    });
    if(this.registrationViewModel.controller.localeCompare("CourseEnquiry")==0){
      this.courseEnquiry=true;
    }
    else
    {
        this.courseEnquiry=false;
    }

  }

}
