import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { ResourceEnquiry } from './resource-enquiry.model';
import { Router } from '@angular/router';
import { Observable, of } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ResourceEnquiryService{
  resourceId;
  formData: ResourceEnquiry = new ResourceEnquiry;
  readonly rootURL="https://localhost:44367/api/ResourceEnquiry/";

  constructor(private http:HttpClient,private router:Router) {

   }

  getResourceEnquiry()
  {
    return this.http.get(this.rootURL);
  }
  
  postResourceEnquiry(formData:ResourceEnquiry)
  {
    alert("Resource Enquiry Added Successfully!");
    return this.http.post(this.rootURL,formData);
  }
  deleteResourceEnquiry(id:number)
  {
    alert("Resource Enquiry Deleted Successfully!");
    return this.http.delete(this.rootURL+id);
  }

  update (id:number,status:string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
    };
    return this.http.put<any>(
      `${this.rootURL}${id}/status/${status}`,
      httpOptions
    );
  }
  
}
