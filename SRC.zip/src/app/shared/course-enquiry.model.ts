export class CourseEnquiry {
    CourseEnquiryId:number=0;
    CourseId:number=0;
    UserName:string='';
    Email:string='';
    PhoneNo:string='';
    Dob:Date=new Date('2019-08-08');
    Qualification:string='';
    TestScore:number=0;   
    EnquiryStatus:string="Enquired"; 
}

