import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseEnquiryListComponent } from './course-enquiry-list.component';

describe('CourseEnquiryListComponent', () => {
  let component: CourseEnquiryListComponent;
  let fixture: ComponentFixture<CourseEnquiryListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CourseEnquiryListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseEnquiryListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
