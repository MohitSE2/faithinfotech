import { Component, OnInit, ViewChild } from '@angular/core';
import { ResourceEnquiryService } from 'src/app/shared/resource-enquiry.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { updateStatus } from 'src/app/course-enquiries/course-enquiry-list/updateStatus';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-resource-enquiry-list',
  templateUrl: './resource-enquiry-list.component.html',
  styleUrls: ['./resource-enquiry-list.component.css']
})
export class ResourceEnquiryListComponent implements OnInit {

  resourceEnquiry: any;
  registrationViewModel: updateStatus= new updateStatus();
  @ViewChild("registrationForm") form: FormControl;

  constructor(public service:ResourceEnquiryService, private router:ActivatedRoute) { }

  ngOnInit(): void {
    this.service.getResourceEnquiry().subscribe(res=>{
      this.resourceEnquiry=res;
      // console.log(res);
    });
  }

  statusUpdate(): void{
    this.service.update(this.registrationViewModel.Id,this.registrationViewModel.EnquiryStatus).subscribe(
      (item) => {
        alert(`Updated Successfully`);
      },
      (error) => {
        alert("Status not Updated");
      }
      
    )
    
  }

}
