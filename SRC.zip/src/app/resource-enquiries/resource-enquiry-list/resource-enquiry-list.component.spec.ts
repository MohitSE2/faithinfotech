import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResourceEnquiryListComponent } from './resource-enquiry-list.component';

describe('ResourceEnquiryListComponent', () => {
  let component: ResourceEnquiryListComponent;
  let fixture: ComponentFixture<ResourceEnquiryListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResourceEnquiryListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResourceEnquiryListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
