export class Register {
    UserId: number = 0;
    UserName: string;
    PhoneNo: string;
    Email: string;
    Password: string;
    RolesId:string;
    Accepted: boolean= true;
  }