import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ResourceesComponent } from './resourcees/resourcees.component';
import { ResourceComponent } from './resourcees/resource/resource.component';
import { ResourceListComponent } from './resourcees/resource-list/resource-list.component';
import { ResourceService } from './shared/resource.service';
import { CourseService } from './shared/course.service';
import { CourseComponent } from './courses/course/course.component';

import { CoursesComponent } from './courses/courses.component';
import { CourseListComponent } from './courses/course-list/course-list.component';
import { CourseEnquiriesComponent } from './course-enquiries/course-enquiries.component';
import { CourseEnquiryComponent } from './course-enquiries/course-enquiry/course-enquiry.component';
import { CourseEnquiryListComponent } from './course-enquiries/course-enquiry-list/course-enquiry-list.component';
import { ResourceEnquiriesComponent } from './resource-enquiries/resource-enquiries.component';
import { ResourceEnquiryComponent } from './resource-enquiries/resource-enquiry/resource-enquiry.component';
import { ResourceEnquiryListComponent } from './resource-enquiries/resource-enquiry-list/resource-enquiry-list.component';
import { ManagerComponent } from './manager/manager.component';
import { ResourceDetailedListComponent } from './resourcees/resource-list/resource-detailed-list/resource-detailed-list.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AccountModule } from './account/account.module';
import { SecurityService } from './security/security.service';
import { AuthInterceptor } from './security/auth.intercepter';
import { InsightService } from './manager/insights/insights.service';
import { SummaryComponent } from './manager/summary/summary.component';
import { CourseEnquiryService } from './shared/course-enquiry.service';
import { UpdateCourseComponent } from './courses/update-course/update-course.component';
import { UpdateServiceService } from './shared/update-service.service';
import { UpdateResourceComponent } from './resourcees/update-resource/update-resource.component';

@NgModule({
  declarations: [
    AppComponent,
    ResourceesComponent,
    ResourceComponent,
    ResourceListComponent,
   CourseComponent,
    CoursesComponent,
    CourseListComponent,
    CourseEnquiriesComponent,
    CourseEnquiryComponent,
    CourseEnquiryListComponent,
    ResourceEnquiriesComponent,
    ResourceEnquiryComponent,
    ResourceEnquiryListComponent,
    ManagerComponent,
    ResourceDetailedListComponent,
    DashboardComponent,
    SummaryComponent,
    UpdateCourseComponent,
    UpdateResourceComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AccountModule,
  ],
  providers: [ResourceService, CourseService,SecurityService,
    InsightService,CourseEnquiryService,UpdateServiceService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },],
  bootstrap: [AppComponent]
})
export class AppModule { }
