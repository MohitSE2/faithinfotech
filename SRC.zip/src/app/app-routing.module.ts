import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './account/login/login.component';
import { RegisterComponent } from './account/register/register.component';


import { CourseEnquiriesComponent } from './course-enquiries/course-enquiries.component';
import { CourseEnquiryComponent } from './course-enquiries/course-enquiry/course-enquiry.component';
import { CourseComponent } from './courses/course/course.component';
import { CoursesComponent } from './courses/courses.component';
import { UpdateCourseComponent } from './courses/update-course/update-course.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InsightsComponent } from './manager/insights/insights.component';
import { ManagerComponent } from './manager/manager.component';
import { SummaryComponent } from './manager/summary/summary.component';
import { NotFoundComponent } from './not-found.component';
import { ResourceEnquiriesComponent } from './resource-enquiries/resource-enquiries.component';
import { ResourceEnquiryComponent } from './resource-enquiries/resource-enquiry/resource-enquiry.component';
import { ResourceComponent } from './resourcees/resource/resource.component';
import { ResourceesComponent } from './resourcees/resourcees.component';
import { UpdateResourceComponent } from './resourcees/update-resource/update-resource.component';
import { AuthGuard } from './security/auth.guard';

const routes: Routes = [
  {path: "",component: LoginComponent},
  {path: "Register",component: RegisterComponent},
  {path:'courses',component:CoursesComponent,canActivate:[AuthGuard],data:{permittedRoles:['Administrator','SuperUser']} },
  {path:"courses/course",component:CourseComponent,canActivate:[AuthGuard],data:{permittedRoles:['Administrator','SuperUser']}},
  {path:"courseEnquiries",component:CourseEnquiriesComponent},
  {path:"courses/updateCourse",component:UpdateCourseComponent, canActivate:[AuthGuard],data:{permittedRoles:['Administrator','SuperUser']}},
  {path:"courseEnquiries/courseEnquiry",component:CourseEnquiryComponent,canActivate:[AuthGuard],data:{permittedRoles:['Administrator','SuperUser']}},
  {path:"resources/updateResource",component:UpdateResourceComponent, canActivate:[AuthGuard],data:{permittedRoles:['Administrator','SuperUser']}},
  {path:'resources',component:ResourceesComponent},
  {path:'resources/resource',component:ResourceComponent,canActivate:[AuthGuard],data:{permittedRoles:['Administrator','SuperUser']}},
  {path:"resourceEnquiries",component:ResourceEnquiriesComponent},
  {path:"resourceEnquiries/resourceEnquiry",component:ResourceEnquiryComponent,canActivate:[AuthGuard],data:{permittedRoles:['Administrator','SuperUser']}},
  {path:'manager/insights',component:InsightsComponent,canActivate:[AuthGuard],data:{permittedRoles:['Manager','SuperUser']}},
  {path:'manager/summary',component:SummaryComponent,canActivate:[AuthGuard],data:{permittedRoles:['Manager','SuperUser']}},
  
  {path:'manager',component:ManagerComponent,canActivate:[AuthGuard],data:{permittedRoles:['Manager','SuperUser']}},

  {path:'dashBoard',component:DashboardComponent,canActivate:[AuthGuard],data:{permittedRoles:['Administrator','SuperUser','Manager']}},

  {path: "**",component: NotFoundComponent},
];

@NgModule({
  imports: [CommonModule,RouterModule.forRoot(routes),RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
